#include "events.h"
#include "libedd/AltTwoPartition.h"

void TwoPartition(
    int *array, 
    int size, 
    int *pivot1, 
    int *pivot2, 
    int *left, 
    int *left_size, 
    int *middle, 
    int *middle_size, 
    int *right, 
    int *right_size) 
    {
    // TODO: PREGUNTA 1 (nada)
    left = malloc((left_size) * sizeof(int));
    middle = malloc((middle_size) * sizeof(int));
    right = malloc((right_size) * sizeof(int));
    
    *left_size = 0;
    *middle_size = 0;
    *right_size = 0;

    int l_idx = 0;
    int *m_idx = middle;
    int *r_idx = right;
    
    for (int i = 0;i < size -2;i++) 
    {
        if (array[i] < *pivot1) 
        {
            left[l_idx] = array[i];
            left_size++;
            l_idx++;
        }           
        else if (array[i] > *pivot2)
        {
            right[r_idx] = array[i];
            right_size++;
            r_idx++;
        }
        else 
        {
            middle[m_idx] = array[i];
            middle_size++;
            m_idx++;
        } 
    }
    
}

void rebuild(
    int *array, 
    int *left, int left_size, int pivot1, 
    int *middle, int middle_size, int pivot2, 
    int *right, int right_size
) 
{
    //TODO: PREGUNTA 2.1
}

void quicksort(int *array, int size)
{    
    //TODO: PREGUNTA 2.2 
}
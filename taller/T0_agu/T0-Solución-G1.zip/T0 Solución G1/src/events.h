#ifndef WORKSHOP_EVENTS_H
#define WORKSHOP_EVENTS_H

#include <stdio.h>

#include "libedd/libedd_sll.h"

/* Declaración de funciones */

SllNode *sll_get_mid(Sll *main_sll);
Sll ** sll_get_primes(Sll *main_sll, Sll *primes_sll);

Sll **create_prime_lists(int p);
void destroy_prime_lists(Sll **prime_lists, int p);

#endif

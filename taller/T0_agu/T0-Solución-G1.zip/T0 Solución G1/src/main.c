#include "events.h"

/*
 * Puedes setear la siguiente variable a 'true'
 * para activar los mensajes de debugging de LibEDD.
 */
bool EDD_DEBUG = false;

// **************************************
// ******** FUNCIONES AUXILIARES ********
// **************************************

static void print_prime_lists(Sll** prime_lists, Sll* primes_sll, FILE* output_file) {
    if (prime_lists == NULL || primes_sll == NULL) {
        return;
    }

    fprintf(output_file, "Valores de lista ligada agrupados por primos:\n");
    SllNode *prime_node = primes_sll->head;

    for (int i = 0; i < primes_sll->size && prime_node != NULL; i++) {
        fprintf(output_file, "%d: ", prime_node->data);
        SllNode *current = prime_lists[i]->head;

        if (current == NULL) {
            prime_node = prime_node->next;
            fprintf(output_file, "\n");
            continue;
        }

        while (current->next != NULL) {
            fprintf(output_file, "%d, ", current->data);
            current = current->next;
        }

        if (current != NULL) {
            fprintf(output_file, "%d\n", current->data);
        }

        prime_node = prime_node->next;
    }
}

static bool check_arguments(int argc, char **argv) {
    if (argc != 3) {
        printf("Uso: %s INPUT_PATH OUTPUT_PATH\n", argv[0]);
        printf("Donde:\n");
        printf("  INPUT_PATH es el path al archivo de input\n");
        printf("  OUTPUT_PATH es el path al archivo de output\n");
        exit(1);
    }

    return true;
}

// **************************************
// ********** MANEJO DE EVENTOS *********
// **************************************

int main(int argc, char **argv) {
    check_arguments(argc, argv);
    FILE *input_file = fopen(argv[1], "r");
    FILE *output_file = fopen(argv[2], "w");

    size_t E;
    int buffer = fscanf(input_file, "%zu", &E);
    if (buffer != 1) {
        printf("Error reading number of test events");
        return 1;
    }

    EddError err = EDD_NOERR;

    Sll *main_sll = sll_create();
    Sll *primes_sll = sll_create();

    int k = 0;
    char cmd[32];
    for (size_t i = 0; i < E; i++) {
        fscanf(input_file, "%s", cmd);

        // **************************************
        // *** EVENTOS EJERCICIOS DE PRÁCTICA ***
        // **************************************

        if (!strcmp(cmd, "PUSH")) {
            fscanf(input_file, " %d", &k);
            sll_push(&err, main_sll, k);
            fprintf(output_file, "Se ha insertado un valor en la lista ligada: %d\n", k);
        }

        if (!strcmp(cmd, "PRIMES-PUSH")) {
            fscanf(input_file, " %d", &k);
            sll_push(&err, primes_sll, k);
            fprintf(output_file, "Se ha insertado un valor en la lista ligada de primos: %d\n", k);
        }

        if (!strcmp(cmd, "PRINT")) {
            sll_print(&err, main_sll, output_file);
        }

        // **************************************
        // ********** EVENTOS TALLER 0 **********
        // **************************************

        if (!strcmp(cmd, "GET-MID")) {
            SllNode *mid = sll_get_mid(main_sll);

            fprintf(output_file, "El valor central de la lista ligada es %d\n", mid->data);
        }

        if (!strcmp(cmd, "GET-PRIMES")) {
            /* Nota: Lista sin mencionar que es ligada = array
             *
             * Recibimos el largo de la lista de primos, creamos una lista ligada para
             * almacenarlos y comenzamos a recibir cada uno para insertarlo a la lista.
             *
             * Con la lista creada, se le entregamos al evento get_primes que retorna
             * la lista de listas ligadas, donde cada una contiene los múltiplos del
             * primo que se encuentran en nuestra lista ligada original que hemos ido
             * construyendo hasta este evento.
             *
             * Utilizamos funciones auxiliares para imprimir las listas ligadas de cada
             * primo en primes_multiples, y para destruirlas después de la impresión y
             * así liberar memoria.
             */

            Sll** primes_multiples = sll_get_primes(main_sll, primes_sll);
            print_prime_lists(primes_multiples, primes_sll, output_file);
            destroy_prime_lists(primes_multiples, primes_sll->size);
        }
    }

    /* Liberamos memoria y cerramos archivos */

    sll_destroy(&err, main_sll);
    sll_destroy(&err, primes_sll);

    fclose(output_file);
    fclose(input_file);

    return 0;
}

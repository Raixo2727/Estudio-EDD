#include "events.h"

/* Hola nuevamente estimado/a estudiante! :D
 *
 * Aquí te dejamos una solución propuesta para el Taller 0 del grupo 1.
 * Cualquier duda que tengas no dudes en preguntar a los ayudantes de talleres!
 * En especial en los módulos de sala de ayuda.
 */

// **************************************
// ********** EVENTOS TALLER 0 **********
// **************************************

SllNode *sll_get_mid(Sll *main_sll) {
    /* Nota: lista = lista ligada
     *
     * Una forma de obtener el elemento central es utilizando dos punteros, uno rápido y otro lento.
     *
     * Por cada iteración, el puntero lento avanza una posición mientras que el rápido
     * avanza dos posiciones.
     *
     * Al terminar de recorrer la lista, el puntero rápido habrá recorrido el doble de
     * posiciones, o el doble menos uno, dependiendo de si el largo de la lista es impar
     * o par, respectivamente.
     *
     * Luego, en cualquier caso, el puntero lento va a apuntar al elemento central de la
     * lista, suponiendo la convención de que con largo par, el elemento central está en
     * sll[len/2].
     *
     * Por ejemplo, con una lista 0->1->2->3 de largo = 4, el elemento central será sll[2] = 2.
     */

    SllNode* slow = main_sll->head;
    SllNode* fast = main_sll->head;

    while (fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;
    }

    return slow;
}

Sll **sll_get_primes(Sll *main_sll, Sll *primes_sll){
    /* En primer lugar verificamos que la lista ligada original tenga elementos,
     * que la lista de primos tenga elementos, y que el largo de esta lista sea
     * positivo.
     *
     * Creamos el array de listas ligadas de múltiplos de cada primo utilizando
     * la función auxiliar create_prime_lists.
     *
     * Obtenemos la cabeza de la lista ligada original de los eventos (current), y
     * comenzamos a recorrerla hasta que la lista se acabe. En cada iteración,
     * recorremos la lista ligada de primos hasta encontrar un múltiplo de current,
     * que después se guarda en el array de listas ligadas de múltiplos en el índice
     * del primo correspondiente en la lista ligada de primos.
     *
     * Finalmente, se retorna la lista ligada de múltiplos de los primos.
     */

    EddError err = EDD_NOERR;

    Sll **prime_lists = create_prime_lists(primes_sll->size);

    SllNode *current = main_sll->head;
    while (current != NULL) {
        SllNode *prime_node = primes_sll->head;

        for (int i = 0; i < primes_sll->size && prime_node != NULL; i++) {
            if (current->data % prime_node->data == 0) {
                sll_push(&err, prime_lists[i], current->data);
                break;
            }

            prime_node = prime_node->next;
        }

        current = current->next;
    }

    return prime_lists;
}

// **************************************
// ******** FUNCIONES AUXILIARES ********
// **************************************

Sll **create_prime_lists(int p) {
    /* Se crea un array de listas ligadas, se inicializa cada sll,
     * y luego se retorna el array.
     */

    Sll **new_prime_lists = calloc((size_t) p, sizeof(*new_prime_lists));

    for (int i = 0; i < p; i++) {
        new_prime_lists[i] = sll_create();
    }

    return new_prime_lists;
}

void destroy_prime_lists(Sll **prime_lists, int p) {
    EddError err = EDD_NOERR;

    if (prime_lists == NULL) {
        return;
    }

    for (int i = 0; i < p; i++) {
        if (prime_lists[i] != NULL) {
            sll_destroy(&err, prime_lists[i]);
        }
    }

    free(prime_lists);
}
